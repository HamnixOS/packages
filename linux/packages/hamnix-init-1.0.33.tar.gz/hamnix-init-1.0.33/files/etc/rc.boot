# /etc/rc.boot — the boot script of THIS MACHINE.
#
# One line, on purpose. /etc/rc.boot is what hamsh runs as PID 1, so it is the
# one file on an installed system whose contents are a property of the MACHINE
# and not of any package: the installer wrote it, and nobody who types
# `hpm update` is asking for their boot configuration to be replaced.
#
# So the machine's copy is an indirection and nothing else. Everything that
# can be improved by a release lives in /etc/rc.boot.installed, which
# hamnix-init DOES own and an update DOES deliver; anything specific to this
# box is added here, below the source line, where no package will touch it.
# hpm knows this path is machine-owned (user/hpm.ad:_is_machine_owned): it
# will write this file when it is ABSENT -- repairing a machine that lost its
# rc -- and will neither overwrite nor delete it when it is there.
#
# The live image does NOT use this file: it boots etc/rc.boot.linux, staged as
# /etc/rc.boot by scripts/hamlinux_image.sh into an initramfs root that the
# next boot throws away.
#
# See docs/linux_installed_update.md §2b for the two measured failures that
# produced this shape -- a package taking the running system's rc, and a
# package deleting it.

# WHO IS SITTING HERE. These three lines are why this file is no longer one
# line, and they are here rather than in /etc/rc.boot.installed on purpose.
#
# WHAT THEY DO: `/etc/rc.login` starts a login program on every terminal, and
# `supervise` is a hamsh builtin that NEVER RETURNS. Without the second one
# the first one changes nothing: /etc/rc.boot is what hamsh runs AS PID 1, and
# when it ends PID 1 falls through into its own interactive prompt -- an
# unauthenticated uid 0 shell on the console of a machine that just booted.
# `supervise` keeps PID 1 alive and working (it reaps children and drains the
# init/service mailbox, so `init 0` and `init 6` still work) while never
# reading the console, so main() never reaches that prompt.
#
# WHY NOT IN /etc/rc.boot.installed, which is where improvable things go:
# BECAUSE THAT FILE IS SOURCED, NOT RUN. Every gate in tests/linux/ that
# measures an installed machine writes its own /etc/rc.boot which begins
# `source '/etc/rc.boot.installed'` and then does its work and powers off. A
# `supervise` inside the sourced file would never return to any of them --
# every one of those gates would hang at the source line, having measured
# nothing, and the machine would never power off. The verb belongs to the
# top-level rc, which is this file, and a gate that replaces this file is
# opting out of it deliberately and visibly.
#
# THAT IS ALSO THE NEGATIVE CONTROL for the login work: an rc without these
# lines still falls through to a root prompt, which is how the gate proves
# its instrument can SEE a root shell before it is trusted to report none.
#
#
# THE GETTYS NOW START BEFORE RUNLEVEL 5, AND THAT IS THE WHOLE CHANGE
# ===================================================================
# David, 2026-08-20: "the greeter failure should leave a terminal for you to
# debug. just like Linux."
#
# `source '/etc/rc.login'` USED TO BE BELOW `source '/etc/rc.boot.installed'`,
# and that made the machine's own documented recovery path a lie.
# /etc/rc.boot.installed ends by entering runlevel 5, and /etc/rc.d/rc.5 runs
# /bin/hamgreet IN THE FOREGROUND -- PID 1's rc does not continue until
# somebody authenticates on the screen. So on a graphical machine NOTHING
# below that source line had ever run: no getty on any terminal, and no
# `supervise` either. Meanwhile rc.5.linux's own failure branch printed, at
# line 178:
#
#     [rc.5] Why: /var/lib/hamgreet.trace. Log in on a terminal to read it.
#
# There was no terminal to log in on. rc.5.linux's header had asserted the
# opposite in prose -- "the tty logins /etc/rc.login started still working" --
# since the day it was written; moving this one line up is what makes that
# sentence true rather than aspirational.
#
# THE LINUX SHAPE, WHICH IS WHAT WAS ASKED FOR: gettys own the terminals and
# come up early; the display manager owns the screen and comes up after. Kill
# the greeter and the serial console and the VTs are still there.
#
# WHAT WAS DELIBERATELY *NOT* DONE, because it would have reintroduced the
# defect the greeter exists to fix. hamgreet is NOT backgrounded and rc.5 is
# NOT restructured. It still blocks PID 1's rc, it still clears
# `hamsession_ok = 0` before and tests it after, and /var/lib/hamsession.rc --
# which only an authenticated greeter writes, and which it unlinks on entry --
# is still the only thing that can raise it. tests/linux/graphical_login.sh
# measures that no session process exists before authentication with a PROCESS
# CENSUS, not with OCR (a screendump cannot tell a display manager from a lock
# screen), and its red arm goes red by starting a session first. Backgrounding
# the greeter would make that arm green while the machine handed out an
# unauthenticated desktop. The recovery terminal was buyable without touching
# it, so it was bought without touching it.
#
# WHY THIS FILE AND NOT /etc/rc.boot.installed, given that this one is
# MACHINE-OWNED and hpm will not overwrite it on an existing box: because
# /etc/rc.boot.installed is SOURCED BY 32 GATES, and a getty on /dev/ttyS0 is
# a READER OF THE SERIAL PORT. Putting the getty start there would hand every
# one of those gates a second reader competing for the keystrokes their driver
# sends -- the exact race etc/rc.login.linux warns about ("Two readers on one
# 8250 would race for each keystroke and each would get a random half of the
# password"). The cost of keeping it here is stated plainly rather than hidden:
# a machine installed BEFORE this change keeps the old order until its
# /etc/rc.boot is replaced or removed, because that is what machine-owned
# means. New installs get it, and hpm writes this file when it is ABSENT.
source '/etc/rc.login'

source '/etc/rc.boot.installed'

supervise
