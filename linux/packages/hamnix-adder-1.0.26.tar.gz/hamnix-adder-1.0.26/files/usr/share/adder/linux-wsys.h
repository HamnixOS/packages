/* user/linux-wsys.h — the seam between the syscall runtime and the window
 * system device.  See user/linux-wsys.c for what these mean.
 *
 * This is the Linux port of sys/src/9/port/devwsys.ad.  In Hamnix that is
 * KERNEL code: the window table, the per-window scene buffers and the event
 * rings live in kernel memory, and both the clients and the compositor poke
 * the same storage through /dev/wsys.  The faithful port of shared kernel
 * memory is shared memory — not an RPC server — so that is what this is.
 *
 * PERMISSION.  devwsys's uid gate is ported too; see THE UID GATE in
 * user/linux-wsys.c.  Reads are never refused.  A write is refused with
 * EPERM — from hamwsys_open when opening for writing already mutates, and
 * again from hamwsys_write — when the caller is neither the host owner (the
 * uid that owns the segment, root on a real boot) nor the owner of the
 * window being addressed.  Ordinary client operations, `newwindow` and
 * everything under the caller's own wid, are open to every uid: that is what
 * the segment's 0666 mode is for.
 *
 * TWO SEGMENTS, which is what makes that gate real for the system chrome.
 * /srv/wsys stays 0666 and holds the window table — a client of any uid must
 * be able to map and draw its own window or the DE session is blind.
 * /srv/wsys.chrome is 0644 and owned by the host owner, and holds the screen
 * geometry and the chrome sinks; non-owners map it PROT_READ, so the kernel
 * refuses a chrome write even to a program that skips this file entirely.  The
 * rule for which state goes where, and what is still NOT covered, is THE SPLIT
 * in user/linux-wsys.c.
 */
#ifndef HAMNIX_LINUX_WSYS_H
#define HAMNIX_LINUX_WSYS_H

#include <stdint.h>

/* Leaf kinds.  HAMWSYS_NONE means "this path is not part of /dev/wsys". */
enum {
    HAMWSYS_NONE = 0,
    HAMWSYS_CTL,          /* /dev/wsys/ctl        — global verbs + newwindow */
    HAMWSYS_SELF,         /* /dev/wsys/self       — this task's wid, if any  */
    HAMWSYS_WINDOWS,      /* /dev/wsys/windows    — "<wid> <title>\n" each   */
    HAMWSYS_SCREEN,       /* /dev/wsys/screen     — "<w> <h>\n", read-only   */
    HAMWSYS_POOL,         /* /dev/wsys/pool       — the v2 paint pool, read- */
                          /*   only: how many backbuffer slots exist, how    */
                          /*   many are in use, and how many times one was   */
                          /*   REFUSED.  A window with no slot is never      */
                          /*   painted and cannot say so itself; this is how */
                          /*   that condition is read back.                  */
    HAMWSYS_DIR,          /* /dev/wsys, /dev/wsys/<wid> — directory listing  */
    HAMWSYS_WIN_CTL,      /* /dev/wsys/<wid>/ctl                             */
    HAMWSYS_WIN_WCTL,     /* /dev/wsys/<wid>/wctl — Plan 9 rio's per-window  */
                          /*   control file: version/focus/resize/move, and  */
                          /*   a read of the LIVE rect. devwsys.ad's "DE      */
                          /*   primitive". lib/hamui.ad negotiates v2 here.  */
    HAMWSYS_WIN_SCENE,    /* /dev/wsys/<wid>/scene                           */
    HAMWSYS_WIN_KEYS,     /* /dev/wsys/<wid>/keys                            */
    HAMWSYS_WIN_POINTER,  /* /dev/wsys/<wid>/pointer                         */
    HAMWSYS_WIN_EVENT,    /* /dev/wsys/<wid>/event                           */
    HAMWSYS_WIN_TEXT,     /* /dev/wsys/<wid>/text                            */
    HAMWSYS_WIN_CMD,      /* /dev/wsys/<wid>/cmd                             */
    HAMWSYS_DRAWCTL,      /* /dev/wsys/<wid>/draw/ctl — the v2 blit protocol */
    HAMWSYS_BACKBUF,      /* /dev/wsys/<wid>/backbuffer — the v2 pixels       */
    HAMWSYS_IMAGES,       /* /dev/wsys/<wid>/draw/images — the named-image    */
                          /*   directory: "<name> <w> <h> <serial>\n" each    */
    HAMWSYS_IMAGE,        /* /dev/wsys/<wid>/draw/image/<name> — raw RGBA8888 */
    HAMWSYS_SINK,         /* every other /dev/wsys/... path — a named buffer */
};

/* Per-open state.  Lives inside the runtime's devtab entry. */
struct hamwsys_file {
    int      leaf;
    int      wid;
    int      write;
    uint64_t off;        /* read cursor into `snap`, or write cursor       */
    uint8_t *snap;       /* snapshot-once read image (malloc'd), or NULL   */
    uint64_t snaplen;
    /* DRAW/CTL REASSEMBLY, per descriptor.  A client may split one draw
     * record across write(2) calls; the remainder waits here for the rest.
     * Grown on demand and capped at WSYS_CARRY_CAP (linux-wsys.c) -- it was a
     * fixed 1 MiB array smaller than one frame of the largest window this
     * build supports, which refused every split blit over that size.
     *
     * PER DESCRIPTOR and not per process, which is the second half of the same
     * fix: as a file-scope static it was shared by every window a process
     * owned, so two windows part-way through a record spliced their bytes
     * together.  user/wsyswl.ad holds one draw/ctl fd per window and is
     * exactly that shape. */
    uint8_t *carry;      /* reassembly buffer (malloc'd), or NULL          */
    uint64_t carrycap;   /* bytes allocated at `carry`                     */
    uint64_t carried;    /* bytes of a partial record held there           */
    char     name[64];   /* HAMWSYS_SINK: the path below /dev/wsys/        */
    /* SINK STAGING -- WHY A SINK IS NO LONGER TRUNCATED ON OPEN.
     * Opening a sink for writing used to set the shared `len` to 0 and let
     * the body arrive in a later write(2).  Between those two syscalls the
     * sink WAS EMPTY to every reader, and a reader landing there got a
     * zero-length body with exit status 0 -- measured at 25 in 100000 tight
     * reads of /dev/wsys/wsysd/state on a live desktop.  That is this
     * project's defining failure shape (a gap answering something
     * success-shaped) pointed straight at the instruments: one such read
     * became a frame delta of plus-or-minus a whole counter in the FPS
     * driver, and reads as "focus is none" in de_focus_dismiss.sh.
     *
     * So the body is assembled HERE, in the writer's own memory, and the
     * shared sink is overwritten only once the whole body is in hand.  A
     * reader now sees the whole previous version or the whole new one.
     *
     * Grown on demand and capped at WSYS_SINK_CAP -- the same shape as
     * `carry` above, and capped at the SINK'S OWN capacity rather than at
     * some number picked here, so there is no fixed buffer for a peer to
     * outgrow: anything the sink cannot hold could not have been published
     * either way. */
    uint8_t *stage;      /* HAMWSYS_SINK write: the body being assembled   */
    uint64_t stagecap;   /* bytes allocated at `stage`                     */
    uint64_t stagelen;   /* bytes of the body assembled so far             */
    int      staged;     /* opened for writing: publish even if never written */
    /* STAGE 6, and it is PER-OPEN because the thing it records is: opening
     * <wid>/scene for writing STARTS A FRAME.  A routed client sends that fact
     * with its first write instead of clearing the display list itself, and a
     * client may hold two scenes open at once, so a global would start the
     * wrong window's frame. */
    int      srv_newframe;
};

int     hamwsys_kind(const char *path);
int     hamwsys_open(const char *path, int for_write, struct hamwsys_file *f);
int64_t hamwsys_read(struct hamwsys_file *f, uint8_t *buf, uint64_t cap);
int64_t hamwsys_write(struct hamwsys_file *f, const uint8_t *buf, uint64_t n);
void    hamwsys_close(struct hamwsys_file *f);

/* THE IDLE PARK.  sys_waitfds (user/linux-syscalls.c) uses these to sleep a
 * scene client off the runqueue until input lands in one of its rings.  A
 * /dev/wsys descriptor is a descriptor on /dev/null, so poll(2) calls it
 * readable instantly and always; without this seam every parking event loop
 * on the system is a busy spin.  See THE PARK in user/linux-wsys.c. */
/* THE CLIENT WAKE. hamwsys_wake_listen() binds an abstract AF_UNIX datagram
 * name derived from the segment and returns a POLLABLE fd; any process that
 * publishes a change (shm->gen moves) sends a byte to it. The compositor
 * appends the fd to its ordinary wait set, which keeps sys_waitfds on its
 * single uncapped poll(2) arm -- a /dev/wsys ring in that set would instead
 * force a FUTEX_WAIT that an evdev fd can never wake. Drain it on every wake:
 * an unread datagram stays readable and would turn the park into a spin. */
int      hamwsys_wake_listen(void);
void     hamwsys_wake_drain(void);

int      hamwsys_is_ring(const struct hamwsys_file *f);
int      hamwsys_ring_ready(const struct hamwsys_file *f);

/* ==================================================================
 * THE MEDIATOR'S TRANSPORT — STAGE 1 OF docs/wsys_server_design.md
 * ==================================================================
 * Everything below is INERT unless HAMWSYS_SERVER=1 is in the environment.
 * With the flag unset hamwsys_srv_listen() returns -1 before it touches a
 * socket or the segment, no client ever connects, and every /dev/wsys
 * operation takes exactly the in-process path it takes today. That is the
 * whole acceptance criterion for this stage: a transport that works and
 * changes nothing.
 *
 * WHY A TRANSPORT AT ALL. /dev/wsys is implemented IN-PROCESS: the window
 * system is linked into every client, so a client's write is its own code
 * touching shared memory. There is no mediator inside the object, which is
 * why a same-uid process can read another window's pixels, why win_alloc can
 * race two clients onto one row, and why enumeration is open by design --
 * the reader's own linked-in code answers from shared memory, so there is
 * nowhere a policy could live. tests/linux/wsys_enum_policy.sh states that as
 * a red gate. A server process is the mediator Plan 9 gets from its kernel.
 *
 * THE SHAPE, WHICH CAME FROM MEASUREMENT AND NOT FROM TASTE
 * (tests/linux/wsys_rtt_probe.c, docs/wsys_server_cost.md):
 *
 *   Strict request-reply is the expensive pattern, not volume. Per-op cost
 *   falls 6.30 us one-at-a-time -> 3.14 at 4 -> 2.31 at 16 -> 2.37 at 64.
 *   So EVERY MUTATION THAT RETURNS NO DATA IS FIRE-AND-FORGET: the client
 *   writes and does not wait, and errors come back out of band on the event
 *   ring it is already draining (WSRV_OP_ERR below, tag 0). Only genuinely
 *   interrogative operations block -- newwindow, wctl version negotiation,
 *   and reads.
 *
 * PIXELS DO NOT CROSS. Per-window memfds are handed up from the owner
 * (THE PIXEL HAND-UP in linux-wsys.c) and stay there. That property is what
 * makes the boundary cost 0.12% of a core instead of megabytes a frame, and
 * it is verified rather than assumed: tests/linux/wsys_srv_transport.sh
 * re-runs the write census and requires zero backbuffer bytes.
 *
 * SOCK_SEQPACKET on an abstract name derived from the segment's (dev, ino) --
 * the same naming the client wake above already uses, so there is exactly one
 * way to find this window system. One message is one packet; there is no
 * framing to get wrong and no partial read to resynchronise from.
 *
 * WHAT STAGE 1 DOES NOT DO. No /dev/wsys operation is routed over this yet.
 * Mutations are stage 2, reads and the enumeration policy stage 3, and the
 * WSYS_VERSION bump is stage 4 and LAST -- the bump is what makes a
 * pre-server client refuse rather than silently mmap the segment and bypass
 * the mediator, so bumping before the in-process path is gone would refuse
 * clients on behalf of a boundary that is not yet enforced.
 */

/* Wire constants. Both sides are the same object file, so this is
 * documentation and a probe's contract rather than an ABI -- but the probe
 * checks it, so it is written down. */
enum {
    WSRV_MAGIC_RQ = 0x51525357u,   /* "WSRQ" */
    WSRV_MAGIC_RP = 0x50525357u,   /* "WSRP" */
    WSRV_MAXPAY   = 65536,         /* a scene is <=16 KiB; this is headroom  */
    WSRV_CONN_MAX = 64,            /* concurrent clients the server holds    */

    WSRV_F_REPLY  = 1,             /* set: the caller is blocked on a reply  */
    /* STAGE 5.  Set on the HELLO of a connection that was INHERITED rather
     * than dialled (HAMWSYS_SRV_FD).  It costs the connection hostowner() for
     * ever, because SO_PEERCRED still names the process that dialled: a
     * descriptor handed down from a host-owner toolkit would otherwise carry
     * host-owner power to whatever it was handed to.  A client can only ever
     * declare itself adopted, so the flag can lose privilege, never gain it. */
    WSRV_F_ADOPT  = 2,
    /* Set on a scene write that BEGINS a frame -- the wire form of `open the
     * scene for writing`.  Without it the server would have to guess where one
     * display list ends and the next begins, and a guess there is a window
     * that paints last frame's contents for ever. */
    WSRV_F_NEWFRAME = 4,
    /* STAGE 10b.  Set on a WSRV_LEAF_EXISTS question asked for a WRITE open.
     * IT CHANGES NO ANSWER -- the predicate is the same one either way, and it
     * must be, since that identity is the whole argument for routing the write
     * open at all (see WSRV_LEAF_EXISTS below).  It exists so the SERVER'S
     * TRACE can say which open crossed: read and write opens of the same leaf
     * are otherwise one indistinguishable line, and a gate outside the process
     * then cannot tell "the write open was routed" from "the read open next to
     * it was".  This device has now paid twice for a trace that could not
     * attribute what it counted. */
    WSRV_F_FORWRITE = 8,

    WSRV_OP_HELLO = 1,             /* blocks: version handshake              */
    WSRV_OP_NOP   = 2,             /* fire-and-forget: the mutation shape    */
    WSRV_OP_PING  = 3,             /* blocks: the interrogative shape        */
    WSRV_OP_STAT  = 4,             /* blocks: the server's own counters      */
    WSRV_OP_ERR   = 5,             /* server -> client, tag 0, unsolicited   */

    /* STAGE 2 — THE MUTATIONS, which is where the privilege questions live.
     *
     * WRITE is one message for one write to /dev/wsys/ctl or
     * /dev/wsys/<wid>/ctl: open, write, close, all of it, because NEITHER OF
     * THOSE LEAVES HAS PER-OPEN STATE.  The census says open and write come
     * in pairs there (9791 opens, 9790 writes in 12 s of a drag), so the
     * one-shot form is not a shortcut -- it is the shape the traffic already
     * has, and it keeps a mutation at one message instead of three.
     *
     * `wid` names the window; `flags`' low bits carry the leaf, because a
     * message that did not say which file it was writing would be a mediator
     * that has to guess.
     *
     * NEWWIN BLOCKS, and it is the only mutation that does.  It returns data
     * -- the wid -- so there is nothing to be gained by not waiting.  Routing
     * it is also what makes win_alloc's race STRUCTURALLY impossible rather
     * than merely fixed; see THE RACE THAT ROUTING RETIRES at win_alloc.
     */
    WSRV_OP_WRITE  = 6,            /* fire-and-forget: one ctl/wid-ctl write */
    WSRV_OP_NEWWIN = 7,            /* blocks: allocate a row, return the wid */

    /* STAGE 4 — THE READS, AND THE ONE OPERATION THAT CANNOT BE SERVICED
     * FROM THE FRAME LOOP.
     *
     * READ blocks by nature: it returns the bytes.  Stage 1 measured what
     * blocking costs against a server serviced from wsysd's frame loop --
     * p50 32 us, but a p90 of 789 us and a max of 851, because a request that
     * arrives while the compositor is rasterizing waits out the frame.  851
     * us is nearly three times the whole published 0.3 ms input-to-pixel
     * budget, for one operation, and a taskbar re-reading /dev/wsys/windows
     * would pay it on every refresh.
     *
     * So READ IS NOT SERVED BY THE FRAME LOOP AT ALL.  wsysd forks a read
     * server at listen(), on its own abstract name (".../rd"), which does
     * nothing but block in epoll_wait and answer interrogative requests out
     * of the same MAP_SHARED segment.  It never rasterizes, so there is no
     * frame for a read to wait out.  Mutations stay on the frame-loop socket,
     * where stage 2 measured routing making the compositor CHEAPER precisely
     * because the loop coalesces them.
     */
    WSRV_OP_READ   = 8,            /* blocks: one snapshot of a read-only leaf */

    /* Which leaf a WSRV_OP_WRITE or WSRV_OP_READ addresses.  Carried in
     * `flags` above WSRV_F_REPLY. */
    WSRV_LEAF_SHIFT = 8,
    WSRV_LEAF_CTL     = 1,         /* /dev/wsys/ctl                          */
    WSRV_LEAF_WIN_CTL = 2,         /* /dev/wsys/<wid>/ctl                    */
    WSRV_LEAF_WINDOWS = 3,         /* /dev/wsys/windows  — AND A POLICY      */
    WSRV_LEAF_SCREEN  = 4,         /* /dev/wsys/screen                       */
    WSRV_LEAF_POOL    = 5,         /* /dev/wsys/pool                         */
    /* STAGE 6 — the last unrouted mutation.  /dev/wsys/<wid>/scene is the one
     * leaf with PER-OPEN STATE: opening it for writing STARTS A NEW FRAME
     * rather than appending to the old one, and getting that wrong is the
     * defect that made an empty window look full for the life of a test file.
     * So the frame boundary is carried in the message (WSRV_F_NEWFRAME) rather
     * than inferred, and the open sends one of its own with no payload -- an
     * open that resets and a write that appends are two different acts and the
     * wire says which is which. */
    WSRV_LEAF_WIN_SCENE = 6,       /* /dev/wsys/<wid>/scene                  */
    /* STAGE 8 — the other spelling of `geometry`.  /dev/wsys/<wid>/wctl takes
     * move/resize/focus/version, and move/resize on somebody else's window is
     * the SAME ACT as the `geometry` verb stage 2 routed on wid/ctl: a gate on
     * only one of two spellings is not a gate.
     *
     * ITS VERBS DO NOT ALL TRAVEL THE SAME WAY, and that is the whole of what
     * is different about this leaf.  move/resize/focus are fire-and-forget like
     * every other mutation.  `version` IS NOT: it is a negotiation whose ANSWER
     * the client acts on -- lib/hamui.ad's hamui_set_protocol_v2_dims sets
     * h_v2_active only `if n >= 0` on that very write -- so a fire-and-forget
     * `version` would report success for a refusal and every application would
     * silently believe it was v2 while the compositor painted it as v0.  That
     * is the most expensive bug this project has had, and it is the one shape
     * a routed leaf must not reintroduce.  So `version` alone carries
     * WSRV_F_REPLY and the server's rc is the write's return value.  It costs
     * one round trip ONCE PER WINDOW, which is the case stage 1 measured as
     * affordable at 851 us.
     *
     * An UNKNOWN verb is deliberately not routed at all: wctl is a closed set
     * that answers -EINVAL, and the in-process path refuses it without
     * touching the window, so routing it would buy a round trip to reach the
     * same refusal -- or, fire-and-forget, would turn a typo into a success. */
    WSRV_LEAF_WIN_WCTL = 7,        /* /dev/wsys/<wid>/wctl                   */
    /* STAGE 9 — THE ATTRIBUTE READS, and this one is a leaf the WRITE side
     * never needed.  /dev/wsys and /dev/wsys/<wid> are DIRECTORIES, and
     * `cat /dev/wsys` is what walked past stage 4's enumeration policy: the
     * routed `windows` read correctly answered EMPTY to a window-less caller
     * while snap_dir() handed the same caller every used row's wid one path
     * component up, out of shared memory, on the same run.  A policy on one
     * spelling of "which windows exist" and not on the other is not a policy.
     *
     * The wid rides in the header exactly as it does for the per-window
     * leaves: 0 means /dev/wsys itself, non-zero means /dev/wsys/<wid>, and
     * the two answers are different sets of names. */
    WSRV_LEAF_DIR     = 8,         /* /dev/wsys, /dev/wsys/<wid> — directory */
    /* STAGE 10 — EXISTENCE ITSELF, AND IT IS NOT A FILE.  Every other leaf in
     * this enum names something a caller can read; this one names the QUESTION
     * every arm of hamwsys_open() asks before it reads anything, and asks today
     * of the mapped window table: `win_find(f->wid)`.
     *
     * docs/wsys_server_design.md §7.1(2): "A client with no mapping cannot open
     * a leaf, so existence ... must become a server answer before the mapping
     * can go.  This is the largest single piece of unbuilt work in stage 7."
     * Stage 9 routed the three leaves that REPORT attributes; the leaves that
     * report none -- scene, the four rings, keys, backbuffer, draw/images,
     * draw/image/<n> -- still learn a window exists from the table, and the
     * ENOENT they answer for an absent wid is itself the fact stage 9 is
     * withholding one path component away.  Measured, unrouted, uid 1002
     * owning nothing: `cat /dev/wsys/<victim>/draw/images` SUCCEEDS on a live
     * window and is ENOENT on a dead one, so the exit code alone enumerates
     * the table.
     *
     * THE ANSWER IS A RETURN CODE AND NOT A PAYLOAD: rc 0 means "that window
     * exists and you may have it", -ENOENT means "no", and there is nothing to
     * copy.  The predicate is the per-window rule stage 9 established --
     * `hostowner() || owns_wid_ancestry(wid)` -- because that is what
     * <wid>/ctl and <wid>/wctl already answer to, and a device that answered
     * "does it exist" to a looser rule than "what is it" would be a gate on
     * one of two spellings, which this file has now refused to build three
     * times.
     *
     * THE CLIENT CACHES A YES AND NEVER A NO, and that is what keeps this off
     * the per-frame path.  A grant is one round trip per (process, window) for
     * the life of the process -- an application opens its own /keys and /event
     * every frame -- while a refusal is re-asked every time, so a window that
     * comes into existence after a probe is not remembered as absent.  The
     * cached YES is not a bypass: win_find() still runs behind it, so a window
     * destroyed after the grant is still ENOENT, and the cache is dropped
     * whenever the process's uid changes.
     *
     * STAGE 10b — AND IT ANSWERS THE WRITE OPEN TOO, WHICH STAGE 10 SAID IT
     * COULD NOT.  Stage 10 routed the READ opens only, and recorded the reason
     * in this file and in the design doc: "the rule two lines below the write
     * open is owns_wid() -- the CONNECTION question stage 5 introduced -- while
     * the served answer is owns_wid_ancestry(); they are not the same set."
     *
     * THAT WAS WRONG, AND THE CORRECTION IS ONE LINE OF THIS FILE'S OWN CODE.
     * `owns_wid()` is `srv_caller.active ? srv_caller_holds_wid(wid) :
     * owns_wid_ancestry(wid)`, and `srv_caller.active` is set ONLY by
     * srv_as_caller()/srv_as_caller_full(), which are called ONLY inside a
     * server dispatching a request.  hamwsys_open() never runs there -- the
     * mutation server services a routed write by calling
     * hamwsys_write_inner(), not by opening anything.  So at the write open,
     * in the client, `owns_wid(wid)` IS `owns_wid_ancestry(wid)`: the same
     * function, not merely a similar rule.  The connection question is asked
     * at WSRV_OP_WRITE in the server, where the binding lives, and that is
     * untouched.
     *
     * The consequence is that the write open's local gate --
     * `hostowner() || owns_wid(wid)` -- and this served predicate --
     * `hostowner() || owns_wid_ancestry(wid)` -- are THE SAME SET about THE
     * SAME PROCESS.  Routing existence there therefore changes no admission:
     * every caller the local rule would refuse, the server refuses first, and
     * every caller the server grants, the local rule then admits.  What
     * changes is only which refusal a stranger sees, and that is the oracle.
     *
     * AND IT CANNOT REBUILD THE ORACLE IN TWO STEPS.  "Server says exists,
     * local rule then says EPERM" would be the same channel with an extra
     * hop; it is unreachable by the argument above, and made unreachable in
     * fact by open_deny(), which answers ENOENT rather than EPERM whenever the
     * server granted this wid to this process. */
    WSRV_LEAF_EXISTS  = 9,         /* "does <wid> exist, and may I have it"  */
};

/* THE SERVER SIDE. wsysd calls claim() before it touches /dev/wsys at all --
 * it is a client of its own device and must never dial itself -- then
 * listen() once from build_waitset, and service() once per loop iteration.
 *
 * listen() returns an EPOLL fd, not the listening socket. The set of live
 * connections changes as clients come and go; wsysd's wait set is built once.
 * One epoll fd standing for all of them means the wait set never has to be
 * rebuilt and the Adder side never learns how many clients there are.
 *
 * service() is non-blocking and must be called on EVERY wake, including wakes
 * it did not cause: an unread packet stays readable, and an unserviced epoll
 * fd would turn the compositor's park into a spin -- the same trap
 * hamwsys_wake_drain exists for. */
void     hamwsys_srv_claim(void);
int      hamwsys_srv_listen(void);
int      hamwsys_srv_service(void);

/* THE READ SERVER IS FORKED BY listen() AND HAS NO ENTRY POINT HERE, on
 * purpose.  A hamwsys_srv_read_service() the Adder side had to call would put
 * reads back on the frame loop -- the exact 851 us tail the split exists to
 * remove.  The only thing wsysd does about it is exist. */

/* THE CLIENT SIDE, for the stage-1 gate. Returns the number of failures, so
 * zero is the only pass and a stub cannot pass by resolving. Exported to
 * Adder as
 *   extern def sys_wsys_srv_selftest() -> int32
 *   extern def sys_wsys_srv_sustain(ops_per_sec: int32, secs: int32) -> int32 */
int      hamwsys_srv_selftest(void);
int      hamwsys_srv_mutate_selftest(int victim_wid);
int      hamwsys_srv_sustain(int ops_per_sec, int secs);
int      hamwsys_srv_attack_local(int victim_wid);
/* Stage 4's instrument: N routed reads of /dev/wsys/windows, every sample
 * printed, against the 851 us frame-loop tail stage 1 measured.  Exported as
 *   extern def sys_wsys_srv_readlat(n: int32) -> int32 */
int      hamwsys_srv_readlat(int nsamples);

/* STAGE 5 — HANDING THE CONNECTION TO A SPAWNED TASK.
 *
 * A routed mutation must now arrive on the connection that holds the window's
 * row, so a program spawned INTO somebody else's window is refused unless the
 * spawner hands it that connection.  Call with 1 immediately before the spawn
 * and 0 immediately after: in between, this process's server connection is
 * inheritable and named in HAMWSYS_SRV_FD.  Returns 0 if there is a connection
 * to inherit, -1 if there is not (flag unset, no server, dial refused) -- in
 * which case the child behaves exactly as it does today.
 *
 * AFTER any privilege drop, never before: SO_PEERCRED is sampled at connect(2)
 * and the connection carries the dialling process's uid wherever it goes.
 * Exported to Adder as
 *   extern def sys_wsys_srv_handoff(on: int32) -> int32 */
int      hamwsys_srv_handoff(int on);

/* Stage 5's gate driver: hold a window's connection and spawn `self` twice --
 * once WITHOUT the handoff and once WITH it -- so both arms of the property
 * are measured in one process.  Returns a failure count.  Exported as
 *   extern def sys_wsys_srv_conngate(wid: int32, selfpath: Ptr[char],
 *                                   uidgate: Ptr[char]) -> int32 */
/* Stage 6's scene probe: a routed display-list write past the local check.
 *   extern def sys_wsys_srv_scene(victim_wid: int32) -> int32 */
int      hamwsys_srv_scene_selftest(int victim_wid);
/* Stage 8's wctl probe: a routed `move` past the local check, scored on the
 * server's own rc for that one message rather than on a counter delta.
 *   extern def sys_wsys_srv_wctl(victim_wid: int32, local: int32) -> int32 */
int      hamwsys_srv_wctl_selftest(int victim_wid, int local);
/* Dial privileged, drop uid, then write: the arm that proves a connection
 * does not outlive the identity that made it.
 *   extern def sys_wsys_srv_dropwrite(wid: int32, to_uid: int32) -> int32 */
int      hamwsys_srv_dropwrite(int victim_wid, int to_uid);
int      hamwsys_srv_conngate(int wid, const char *self,
                              const char *uidgate);

/* Did THIS process get turned away by the version refusal in shm_attach?
 * Its own experience, not a file another process wrote -- see
 * seg_refused_here in linux-wsys.c. Exported to Adder as
 *   extern def sys_wsys_was_refused() -> int32 */
int      hamwsys_was_refused(void);
uint32_t hamwsys_input_gen(void);
int      hamwsys_input_wait(uint32_t seen, int64_t timeout_ms);

/* THE PIXEL HAND-UP'S HEARTBEAT, and it belongs on the PARK.
 *
 * A window's display list lives in a memfd its owner hands to the compositor
 * (THE PIXEL HAND-UP in user/linux-wsys.c), and the hand-up is the client's
 * own action.  Driving it from the wsys calls a client makes covers a client
 * that is drawing and MISSES THE ONE THAT HAS STOPPED -- an application that
 * paints its window once and then parks makes no wsys call ever again, so a
 * compositor that binds after it (or restarts) would never be handed that
 * window and would paint a blank rectangle for ever with nothing on stderr.
 * Measured: hamimgscene draws one photograph and parks, and it was blank.
 *
 * sys_waitfds is where every such program is.  That is the property being
 * used -- not "somewhere convenient", but the one call a client that is doing
 * nothing at all still makes.  It is gated on a monotonic clock read inside,
 * and returns immediately in a process that owns no window. */
void     hamwsys_tick(void);

/* The two syscalls hamUI uses to bind a spawned task to a window. */
int32_t hamwsys_alloc(uint64_t pid);
int32_t hamwsys_free(int32_t wid);

#endif
