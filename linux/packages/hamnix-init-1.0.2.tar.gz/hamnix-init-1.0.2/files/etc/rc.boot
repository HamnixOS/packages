# /etc/rc.boot.linux — the bootstrap rc for the Linux line, interpreted by
# hamsh running as PID 1.
#
# Staged into the image as /etc/rc.boot. It replaces etc/rc.boot (Hamnix's),
# which cannot run here: that one's whole job is to bring a rootfs partition
# online via `bind '#sysroot' /`, and the #sysroot file server is posted by the
# Hamnix kernel. In an initramfs-only developer boot there is no partition and
# no such server.
#
# What has ALREADY happened by the time this runs, in user/linuxinit.ad (the
# Adder PID 1):
#
#   bind '#p'   /proc      bind '#c'   /dev      bind '#s'  /srv
#   bind '#sys' /sys       bind '#pts' /dev/pts  bind '#/'  /n
#   bind '#t'   /tmp
#
# On this line those binds perform real Linux mounts — see the device-server
# table in user/linux-syscalls.c. The Plan 9 vocabulary is kept on purpose: the
# rc scripts say what they mean and do not need to know which kernel is under
# them.
#
# NOT yet bound, because their file servers are not written:
#   '#I' /net       — HANDOFF §3, the /net file tree
#   '#b' /dev/blk   — block devices
#   '#w' /dev/win   — part of wsys, HANDOFF §4.4
#   '#distro' /     — the Debian namespace
#
# Syntax: '#' starts a comment; device-letter names like '#s' MUST be
# single-quoted; `bind SRC DST` is source-first.

echo 'rc.boot: hamnix-linux starting'

# /dev/cons is Hamnix's console device and the tree writes diagnostics to it
# by name -- lib and the DE apps all do, through their _cons_say helpers.
# devtmpfs has no such node, so the messages went nowhere: a GUI app could be
# reporting a fault every frame and the operator would see silence.
ln -s /dev/console /dev/cons
echo 'rc.boot: kernel is Linux; userland is Adder'

# Nothing else to bring up yet. When /net and wsys land this is where they get
# started, and where rc.d/rc.5 takes over to bring up the desktop.

echo 'rc.boot: handing off to an interactive shell'

# --- WHY THIS SHELL DOES *NOT* DROP PRIVILEGE ------------------------
# Hamnix's own etc/rc.boot ends its live branch with `setuid 1001`, so the
# console you are handed on a live image is the regular user `live`. This one
# deliberately does not, and the difference is forced by the kernel underneath:
#
#   * We ARE PID 1. Linux starts /init as uid 0 and gives us no way to be
#     anything else; more to the point, PID 1 here is also the machine's only
#     administrative shell. It still has to mount (rc.5 and the installer both
#     bind, and mount(2) needs CAP_SYS_ADMIN), load modules, configure eth0,
#     write /bin through hpm, and run hlinstall against a real disk. A setuid
#     is one-way: dropping here would take all of that away permanently, and
#     with /dev/auth unimplemented on this line (user/linux-runtime.S stubs
#     sys_setuid_auth to -1) there would be no way to get it back.
#   * The privilege drop that MATTERS happens where the person actually
#     types: /etc/rc.de-user ends with `setuid 1001`, so every desktop
#     terminal and every program launched from one runs as `live`. That is
#     the session, and it is unprivileged. This console is the operator's
#     seat, not a session.
#
# When a real display manager or a getty/login pair authenticates a named user
# on this line, THAT is what should drop, per-session, to the authenticated
# uid — not this shell. See the report in etc/rc.de-user's closing note.

# --- networking -----------------------------------------------------
# /net is a file tree (user/linux-net.c), but the INTERFACE is configured
# through sys_netcfg -- deliberately not on the tree, in Hamnix as here
# (HANDOFF §3.3). These are the addresses QEMU's user-mode network hands out;
# a real machine gets its own, and the three lines do not change.
#
# STATIC, not DHCP: the kernel's own ip=dhcp runs before the initramfs has
# loaded virtio_net, so it configures nothing, and a DHCP client is a program
# this line does not have yet. Named here rather than hidden, because on real
# hardware this is the line that will need replacing.
ifconfig eth0 10.0.2.15 netmask 255.255.255.0
ifconfig gw 10.0.2.2
ifconfig dns 10.0.2.3
echo 'rc.boot: network configured'

# --- the graphical runlevel -----------------------------------------
# Starts the scene compositor and the desktop session. Comment this line out
# for a text-only boot; nothing below the compositor depends on it.
source '/etc/rc.d/rc.5'

# --- the Debian namespace -------------------------------------------
# `#distro` is a subtree server backed by its own filesystem (a virtio disk
# here). Debian's tree is bound at /n/distro and NOTHING it installs is written
# into the Hamnix filesystem -- that separation is the whole reason for it.
bind '#distro' /n/distro
