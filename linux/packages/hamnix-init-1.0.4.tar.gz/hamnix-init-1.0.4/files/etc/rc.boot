# /etc/rc.boot.linux — the bootstrap rc for the Linux line, interpreted by
# hamsh running as PID 1.
#
# Staged into the image as /etc/rc.boot. It replaces etc/rc.boot (Hamnix's),
# which cannot run here: that one's whole job is to bring a rootfs partition
# online via `bind '#sysroot' /`, and the #sysroot file server is posted by the
# Hamnix kernel. In an initramfs-only developer boot there is no partition and
# no such server.
#
# What has ALREADY happened by the time this runs, in user/linuxinit.ad (the
# Adder PID 1):
#
#   bind '#p'   /proc      bind '#c'   /dev      bind '#s'  /srv
#   bind '#sys' /sys       bind '#pts' /dev/pts  bind '#/'  /n
#   bind '#t'   /tmp
#
# On this line those binds perform real Linux mounts — see the device-server
# table in user/linux-syscalls.c. The Plan 9 vocabulary is kept on purpose: the
# rc scripts say what they mean and do not need to know which kernel is under
# them.
#
# NOT yet bound, because their file servers are not written:
#   '#I' /net       — HANDOFF §3, the /net file tree
#   '#b' /dev/blk   — block devices
#   '#w' /dev/win   — part of wsys, HANDOFF §4.4
#   '#distro' /     — the Debian namespace
#
# Syntax: '#' starts a comment; device-letter names like '#s' MUST be
# single-quoted; `bind SRC DST` is source-first.

echo 'rc.boot: hamnix-linux starting'

# /dev/cons is Hamnix's console device and the tree writes diagnostics to it
# by name -- lib and the DE apps all do, through their _cons_say helpers.
# devtmpfs has no such node, so the messages went nowhere: a GUI app could be
# reporting a fault every frame and the operator would see silence.
ln -s /dev/console /dev/cons

# /dev/fd, and the three names that hang off it.
#
# devtmpfs does not create these -- on a normal Debian system systemd or the
# initramfs does, and nothing here was doing it. The symptom is not a missing
# device: it is that BASH PROCESS SUBSTITUTION stops working, because `<(...)`
# is implemented as /dev/fd/<n>. Steam's own runtime setup uses it, and what
# you get is
#
#   .../steam-runtime/setup.sh: line 131: /dev/fd/63: No such file or directory
#
# from a script that is plainly there, on a system where the shell is fine.
# Every /dev in the tree comes from this one devtmpfs -- including the Debian
# namespace's, which enter_root bind-mounts from here -- so fixing it here
# fixes it for both userlands at once.
ln -s /proc/self/fd /dev/fd
ln -s /proc/self/fd/0 /dev/stdin
ln -s /proc/self/fd/1 /dev/stdout
ln -s /proc/self/fd/2 /dev/stderr

# /dev/shm — POSIX shared memory.
#
# devtmpfs does not provide it and nothing else was mounting it, so every
# shm_open(3) in the system failed. That is invisible until something large
# needs it: Steam's controller subsystem reports
# "Failed creating file mapping SteamController_Master_mem", and Chromium --
# which is what Steam's UI is -- cannot start its renderer at all. Firefox and
# any other browser in the namespace are in the same position.
#
# It is mounted HERE, on the one devtmpfs, so the Debian namespace inherits it:
# enter_root bind-mounts /dev with MS_REC, which carries submounts across.
mkdir /dev/shm
bind '#t' /dev/shm

echo 'rc.boot: kernel is Linux; userland is Adder'

# Nothing else to bring up yet. When /net and wsys land this is where they get
# started, and where rc.d/rc.5 takes over to bring up the desktop.

echo 'rc.boot: handing off to an interactive shell'

# --- WHY THIS SHELL DOES *NOT* DROP PRIVILEGE ------------------------
# Hamnix's own etc/rc.boot ends its live branch with `setuid 1001`, so the
# console you are handed on a live image is the regular user `live`. This one
# deliberately does not, and the difference is forced by the kernel underneath:
#
#   * We ARE PID 1. Linux starts /init as uid 0 and gives us no way to be
#     anything else; more to the point, PID 1 here is also the machine's only
#     administrative shell. It still has to mount (rc.5 and the installer both
#     bind, and mount(2) needs CAP_SYS_ADMIN), load modules, configure eth0,
#     write /bin through hpm, and run hlinstall against a real disk. A setuid
#     is one-way: dropping here would take all of that away permanently, and
#     with /dev/auth unimplemented on this line (user/linux-runtime.S stubs
#     sys_setuid_auth to -1) there would be no way to get it back.
#   * The privilege drop that MATTERS happens where the person actually
#     types: /etc/rc.de-user ends with `setuid 1001`, so every desktop
#     terminal and every program launched from one runs as `live`. That is
#     the session, and it is unprivileged. This console is the operator's
#     seat, not a session.
#
# When a real display manager or a getty/login pair authenticates a named user
# on this line, THAT is what should drop, per-session, to the authenticated
# uid — not this shell. See the report in etc/rc.de-user's closing note.

# --- networking -----------------------------------------------------
# /net is a file tree (user/linux-net.c), but the INTERFACE is configured
# through sys_netcfg -- deliberately not on the tree, in Hamnix as here
# (HANDOFF §3.3). These are the addresses QEMU's user-mode network hands out;
# a real machine gets its own, and the three lines do not change.
#
# STATIC, not DHCP: the kernel's own ip=dhcp runs before the initramfs has
# loaded virtio_net, so it configures nothing, and a DHCP client is a program
# this line does not have yet. Named here rather than hidden, because on real
# hardware this is the line that will need replacing.
ifconfig eth0 10.0.2.15 netmask 255.255.255.0
ifconfig gw 10.0.2.2
ifconfig dns 10.0.2.3

# LOOPBACK. Nothing was bringing `lo` up, and the address on it is not a
# kernel default -- so 127.0.0.1 was unassignable and every program that talks
# to ITSELF over a socket failed. Steam does exactly that for its inter-process
# IPC and reports
#   src/common/processpipe_posix.cpp (325) : Assertion Failed:
#   socket bind failed: Cannot assign requested address
# which says nothing about loopback at all. X, dbus and any local server are
# in the same position.
#
# HAMNIX_IFACE is how the interface is selected: sys_netcfg (user/linux-net.c)
# takes the name from the environment, NOT from ifconfig's first argument, so
# `ifconfig lo ...` on its own would have configured eth0. Set it, configure
# lo, and put it back -- the export is the operative line, not the argument.
HAMNIX_IFACE='lo'
export HAMNIX_IFACE
ifconfig lo 127.0.0.1 netmask 255.0.0.0
HAMNIX_IFACE='eth0'
export HAMNIX_IFACE

echo 'rc.boot: network configured'

# --- the graphical runlevel -----------------------------------------
# Starts the scene compositor and the desktop session. Comment this line out
# for a text-only boot; nothing below the compositor depends on it.
source '/etc/rc.d/rc.5'

# --- the Debian namespace -------------------------------------------
# `#distro` is a subtree server backed by its own filesystem (a virtio disk
# here). Debian's tree is bound at /n/distro and NOTHING it installs is written
# into the Hamnix filesystem -- that separation is the whole reason for it.
bind '#distro' /n/distro

# `enter debian { sh }` from the CONSOLE shell too, not just from a desktop
# terminal. etc/rc.de-user captures these templates for the DE-spawned shell,
# but PID 1 -- the shell you land in on a serial boot, on a headless install,
# and every time the DE is not running -- had no template at all, so the one
# command this subsystem exists to offer did not exist there. Capturing a
# template grants nothing: `ns clean { }` is a description, and what an
# `enter` switches to is the Debian root, never the native one.
#
# `debian` is the name to teach; `linux` is the alias that keeps working
# because etc/install.hamsh and several tests spell it that way. See the note
# in etc/rc.de-user.linux for why `linux` was the wrong name: the kernel under
# BOTH namespaces is Linux, so it distinguishes nothing, and someone typing it
# wants apt and Firefox, not a kernel.
debian = ns clean {
    bind '#distro' /
    bind '#c' /dev
    bind '#p' /proc
    bind '#s' /srv
    bind '#/' /n
}
linux = ns clean {
    bind '#distro' /
    bind '#c' /dev
    bind '#p' /proc
    bind '#s' /srv
    bind '#/' /n
}
